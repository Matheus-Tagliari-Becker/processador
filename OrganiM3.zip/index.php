<?php
$nop = '00000000000000000000000000000000';
$nop_instructions = [];
$linecount = count(file("data.txt"));
$linesread = 0;
echo $linecount . " instruções.<br>";
if ($file = fopen("data.txt", "r")) {
    while(!feof($file)) {
		$linesread++;
        $line = fgets($file);
		array_push($nop_instructions, $line);
        echo $line . "<br>";
		$type = identify($line);
		if ($linesread == $linecount) {
			break;
		}
		if ($type == "R" or $type == "lw" or $type == "I") {
			array_push($nop_instructions, $nop);
			array_push($nop_instructions, $nop);
		}
		if ($type == "others" or $type == "sw" or $type == "branch") {
			array_push($nop_instructions, $nop);
		}
    }
    fclose($file);
	echo "<br><br>INSTRUÇÕES COM NOPS<br><br>";
}
foreach($nop_instructions as $lin){
	echo $lin . "<br>";
}


function identify($line) {
	if ($line == "00000000000000000000000000000000") {
		return "nop";
	}
	$opcode = substr($line, 0, 6);
	if ($opcode == "000000"){
		if (substr($line, 26, 6) == "001100") {
			return "syscall";
		}
		else {
			return "R";
		}
	}
	else if ($opcode == "000010") {
		return "lw";
	}
	else if ($opcode == "101011") {
		return "sw";
	}
	else if ($opcode == "000100" or $opcode == "000101") {
		return "branch";
	}
	else if ($opcode == "000010" or $opcode == "000011" or $opcode == "001000") {
		return "J";
	}
	else {
		return "I";
	}
}
?>